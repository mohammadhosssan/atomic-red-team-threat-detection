# Findings and Analysis

## Analysis Process
- Review console output after each test
- Identify affected system components
- Record exit codes and execution behavior

## Key Observations
- Successful tests highlight detection blind spots
- Failed tests reveal dependency or configuration issues
- Repeated failures may indicate hardened controls

## Recommendations
- Improve logging and endpoint visibility
- Harden PowerShell and system execution policies
- Implement centralized monitoring where applicable
