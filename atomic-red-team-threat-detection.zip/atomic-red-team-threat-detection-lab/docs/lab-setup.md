# Lab Setup

## Environment Preparation
- Use virtual machines only (Windows and/or Linux)
- Ensure administrative privileges are available
- Install PowerShell 5.0 or later

## Setup Steps
1. Open PowerShell as Administrator on Windows
2. On Linux/macOS, run PowerShell with sudo privileges
3. Install Git if not present
4. Clone the Atomic Red Team repository (referenced, not redistributed)

## Notes
- Tests must only be run with permission
- Never execute on production systems
