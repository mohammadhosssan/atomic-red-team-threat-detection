# MITRE ATT&CK Mapping

## Purpose
Mapping observed behaviors to MITRE ATT&CK improves understanding of
adversary techniques and defensive coverage.

## Observed Technique Categories
- Discovery
- Execution
- Persistence

## Defensive Value
- Helps prioritize detection engineering
- Aligns testing with industry frameworks
