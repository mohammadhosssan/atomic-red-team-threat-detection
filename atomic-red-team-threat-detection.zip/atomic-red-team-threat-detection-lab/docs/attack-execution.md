# Attack Execution

## Listing Compatible Tests
Atomic Red Team allows enumeration of tests compatible with the target OS.

## Dependency Checks
Before execution:
- Check required dependencies
- Install missing prerequisites as needed

## Test Execution
- Select specific Atomic test IDs
- Execute tests individually in a controlled manner

## Output Interpretation
- Exit Code 0: Successful execution
- Exit Code 1: Failure or missing dependency
